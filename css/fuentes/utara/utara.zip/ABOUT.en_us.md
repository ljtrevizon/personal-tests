# About Lokal Container Font Repository

This is the sample font repository for the [Unified Font Repository v0.3](https://github.com/raphaelbastide/Unified-Font-Repository), a standard way to organize font project source files.