Esta es la ayuda pa
esto es mio
esto es mio 2.0
Lo edita epicamente